/* ═══════════════════════════════════════
   AURA CHAT — CHAT.JS
   Clean, modular chat engine
═══════════════════════════════════════ */

(function ($) {
  "use strict";

  /* ── State ── */
  const state = {
    messages: [],        // { sender, text, time }
    isTyping: false,
    chatTitle: "New Conversation",
    darkMode: false,
    chatIdCounter: 4,
  };

  /* ── AI Mock Responses ── */
  const AI_RESPONSES = [
    "That's a fascinating question! Let me think about it carefully.\n\nThe core idea here involves several interconnected concepts. When we look at this from first principles, we can see that the answer emerges from understanding the underlying mechanisms at play.",
    "Great point! Here's a clear breakdown:\n\n1. **Start with the fundamentals** — every complex problem has a simple core.\n2. **Build incrementally** — layer your understanding step by step.\n3. **Validate your assumptions** — question what you think you know.\n\nDoes that help clarify things?",
    "Absolutely! This is something I find genuinely interesting.\n\nThe short answer is: it depends on context. But the longer answer involves understanding that `context` itself is a function of the variables you choose to observe — which is precisely why this is such a rich area to explore.",
    "Here's a concise way to think about it:\n\nImagine you're building something from scratch. The first question you'd ask is *why* — purpose drives architecture, architecture drives decisions, decisions drive outcomes. Starting with 'why' changes everything.",
    "Interesting! Let me offer a different perspective.\n\nMost people approach this problem linearly, but the most elegant solutions tend to be recursive — they solve a small version of themselves and then scale. That realization is often the key insight.",
    "I'd suggest breaking this into three phases:\n\n**Phase 1 — Discovery:** Gather context and constraints.\n**Phase 2 — Synthesis:** Identify patterns across the data.\n**Phase 3 — Execution:** Ship iteratively, learn continuously.\n\nThis keeps complexity manageable at each step.",
    "That's a nuanced one! The honest answer is there's genuine disagreement among experts here. But the evidence tends to favor the view that small, consistent actions compound over time far more powerfully than large, sporadic efforts.",
    "Sure — here's a quick analogy that might help:\n\nThink of it like tuning a guitar. Each string needs individual attention, but the music only works when all strings are in harmony. Systems thinking is the same — you optimize the whole, not just the parts.",
    "You're touching on something important. The underlying principle is *leverage* — finding the smallest change that produces the largest effect. In practice, this means ruthlessly prioritising the 20% of inputs that drive 80% of outcomes.",
    "Beautifully framed question. Here's my take:\n\nThe challenge isn't technical — it's almost never purely technical. It's about aligning incentives, building shared understanding, and creating feedback loops that surface problems early. The rest tends to follow.",
  ];

  /* ── Utility: format timestamp ── */
  function formatTime(date) {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  /* ── Auto-resize textarea ── */
  function autoResize($el) {
    $el[0].style.height = "auto";
    $el[0].style.height = Math.min($el[0].scrollHeight, 180) + "px";
  }

  /* ── Scroll to bottom ── */
  function scrollToBottom(smooth) {
    const vp = document.getElementById("messagesViewport");
    vp.scrollTo({ top: vp.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  }

  /* ── Toggle Welcome Screen ── */
  function syncWelcomeScreen() {
    if (state.messages.length > 0) {
      $("#welcomeScreen").addClass("hidden");
    } else {
      $("#welcomeScreen").removeClass("hidden");
    }
  }

  /* ── Build message HTML ── */
  function buildMessageEl(msg) {
    const isUser = msg.sender === "user";
    const rowClass = isUser ? "user-row" : "ai-row";
    const avatarClass = isUser ? "user-avatar" : "ai-avatar";
    const avatarContent = isUser ? "AU" : '<i class="bi bi-stars"></i>';

    const $row = $(`
      <div class="msg-row ${rowClass}">
        <div class="msg-avatar ${avatarClass}">${avatarContent}</div>
        <div class="msg-bubble-wrap">
          <div class="msg-bubble">${escapeHtml(msg.text)}</div>
          <span class="msg-time">${msg.time}</span>
        </div>
      </div>
    `);
    return $row;
  }

  /* ── Escape HTML ── */
  function escapeHtml(text) {
    return text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  /* ── addMessage ── */
  function addMessage(text, sender) {
    const msg = { sender, text, time: formatTime(new Date()) };
    state.messages.push(msg);

    const $el = buildMessageEl(msg);
    $("#messagesList").append($el);
    syncWelcomeScreen();
    scrollToBottom(true);

    // Update chat title from first user message
    if (sender === "user" && state.messages.filter(m => m.sender === "user").length === 1) {
      const title = text.length > 36 ? text.slice(0, 36) + "…" : text;
      state.chatTitle = title;
      $("#chatTitle").text(title);
      // Add to history sidebar
      addToHistory(title);
    }

    return $el;
  }

  /* ── Add entry to sidebar history ── */
  function addToHistory(title) {
    // Deactivate others
    $(".history-item").removeClass("active");
    const id = state.chatIdCounter++;
    const $item = $(`
      <li class="history-item active" data-id="${id}">
        <i class="bi bi-chat-text"></i>
        <span>${escapeHtml(title)}</span>
      </li>
    `);
    // Prepend to top
    $("#historyList").prepend($item);
  }

  /* ── Show / hide typing indicator ── */
  function showTyping() {
    state.isTyping = true;
    $("#typingIndicator").removeClass("hidden");
    scrollToBottom(true);
  }

  function hideTyping() {
    state.isTyping = false;
    $("#typingIndicator").addClass("hidden");
  }

  /* ── Letter-by-letter AI response animation ── */
  function typeAIResponse(text, $bubble, done) {
    let i = 0;
    $bubble.addClass("ai-cursor");
    const CHUNK = 2; // chars per tick
    const DELAY = 18; // ms per tick

    function tick() {
      if (i < text.length) {
        const slice = text.slice(0, i + CHUNK);
        $bubble.text(slice);
        i += CHUNK;
        scrollToBottom(false);
        setTimeout(tick, DELAY);
      } else {
        $bubble.text(text);
        $bubble.removeClass("ai-cursor");
        if (done) done();
      }
    }
    tick();
  }

  /* ── Pick random AI response ── */
  function pickResponse() {
    return AI_RESPONSES[Math.floor(Math.random() * AI_RESPONSES.length)];
  }

  /* ── sendMessage ── */
  function sendMessage() {
    const $input = $("#messageInput");
    const text = $input.val().trim();
    if (!text || state.isTyping) return;

    // Clear + reset input
    $input.val("").trigger("input");
    $input[0].style.height = "auto";
    $("#sendBtn").prop("disabled", true);

    // Add user message
    addMessage(text, "user");

    // Delay before AI responds
    const delay = 900 + Math.random() * 800;
    showTyping();

    setTimeout(function () {
      hideTyping();
      const response = pickResponse();
      const msg = { sender: "ai", text: response, time: formatTime(new Date()) };
      state.messages.push(msg);

      // Build AI row but start with empty bubble
      const $row = $(`
        <div class="msg-row ai-row" style="animation: msgAppear 0.28s cubic-bezier(0.34,1.3,0.64,1) both">
          <div class="msg-avatar ai-avatar"><i class="bi bi-stars"></i></div>
          <div class="msg-bubble-wrap">
            <div class="msg-bubble"></div>
            <span class="msg-time">${msg.time}</span>
          </div>
        </div>
      `);
      $("#messagesList").append($row);
      scrollToBottom(true);

      const $bubble = $row.find(".msg-bubble");
      typeAIResponse(response, $bubble, function () {
        scrollToBottom(true);
      });
    }, delay);
  }

  /* ── Export chat as .txt ── */
  function exportChat() {
    if (state.messages.length === 0) {
      alert("No messages to export yet!");
      return;
    }
    let content = `Aura Chat Export\n`;
    content += `Date: ${new Date().toLocaleString()}\n`;
    content += `Title: ${state.chatTitle}\n`;
    content += "─".repeat(50) + "\n\n";

    state.messages.forEach(function (msg) {
      const label = msg.sender === "user" ? "You" : "Aura";
      content += `[${msg.time}] ${label}:\n${msg.text}\n\n`;
    });

    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const $a = $("<a>")
      .attr({ href: url, download: "aura-chat.txt" })
      .appendTo("body");
    $a[0].click();
    $a.remove();
    URL.revokeObjectURL(url);
  }

  /* ── Start a new chat ── */
  function newChat() {
    state.messages = [];
    state.chatTitle = "New Conversation";
    $("#chatTitle").text("New Conversation");
    $("#messagesList").empty();
    syncWelcomeScreen();
    $(".history-item").removeClass("active");
    closeSidebar();
  }

  /* ── Sidebar helpers ── */
  function openSidebar() {
    $("#sidebar").addClass("open");
    $("#sidebarOverlay").addClass("show");
  }

  function closeSidebar() {
    $("#sidebar").removeClass("open");
    $("#sidebarOverlay").removeClass("show");
  }

  /* ── Dark Mode ── */
  function toggleDarkMode() {
    state.darkMode = !state.darkMode;
    $("body").toggleClass("dark", state.darkMode);
    $("#themeIcon")
      .removeClass("bi-moon-stars-fill bi-sun-fill")
      .addClass(state.darkMode ? "bi-sun-fill" : "bi-moon-stars-fill");
    // Persist
    localStorage.setItem("aura-dark", state.darkMode ? "1" : "0");
  }

  /* ── Init dark mode from storage ── */
  function initDarkMode() {
    const saved = localStorage.getItem("aura-dark");
    if (saved === "1") {
      state.darkMode = true;
      $("body").addClass("dark");
      $("#themeIcon").removeClass("bi-moon-stars-fill").addClass("bi-sun-fill");
    }
  }

  /* ── Event Bindings ── */
  function bindEvents() {
    // Send on button click
    $("#sendBtn").on("click", sendMessage);

    // Send on Enter, newline on Shift+Enter
    $("#messageInput").on("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });

    // Auto-resize textarea & toggle send button
    $("#messageInput").on("input", function () {
      autoResize($(this));
      const empty = $(this).val().trim() === "";
      $("#sendBtn").prop("disabled", empty || state.isTyping);
    });

    // Suggestion cards
    $(document).on("click", ".suggestion-card", function () {
      const prompt = $(this).data("prompt");
      $("#messageInput").val(prompt).trigger("input");
      sendMessage();
    });

    // New Chat
    $("#newChatBtn").on("click", newChat);

    // Export
    $("#exportBtn").on("click", exportChat);

    // Theme toggle
    $("#themeToggle").on("click", toggleDarkMode);

    // Sidebar mobile
    $("#sidebarToggle").on("click", openSidebar);
    $("#sidebarClose").on("click", closeSidebar);
    $("#sidebarOverlay").on("click", closeSidebar);

    // History items
    $(document).on("click", ".history-item", function () {
      $(".history-item").removeClass("active");
      $(this).addClass("active");
      // For demo: just close sidebar on mobile
      if ($(window).width() < 992) closeSidebar();
    });
  }

  /* ── DOM Ready ── */
  $(function () {
    initDarkMode();
    bindEvents();
    syncWelcomeScreen();
    // Focus input
    $("#messageInput").trigger("focus");
  });

})(jQuery);
