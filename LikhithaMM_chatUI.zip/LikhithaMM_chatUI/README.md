# Chat UI Assignment

## Description
A responsive chat interface inspired by ChatGPT/Claude built using HTML, CSS, JavaScript, jQuery, and Bootstrap 5.

## Features
- Responsive design (Added some animations and glow, hardcoded the logo and made the UI aesthetically pleasing) refer screenshot 1
- Chat bubbles (user & AI) refer screenshot 7
- Welcome page with suggestion cards. refer screenshot 2
- Welcome page dissapears once we start chatting. refer screenshot 7
- Typing indicator. refer screenshot 8
- Sidebar with chat history, export chat, settings button and user profile. refer screenshot 1,5
- Auto-scroll during response generation.
- Disabled send button when there's no message in the box. refer screenshot 3
- Both light and dark modes available. refer screenshot 1,4
- Input handling
- Mock AI responses hardcoded.

## How to Run
1. Open index.html in browser
2. Start chatting

## Tech Used
- HTML5
- CSS3
- JavaScript
- jQuery
- Bootstrap 5